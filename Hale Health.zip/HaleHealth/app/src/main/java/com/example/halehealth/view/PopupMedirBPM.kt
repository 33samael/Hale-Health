package com.example.halehealth.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.R

class PopupMedirBPM : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.popup_frequencia)

    }
}