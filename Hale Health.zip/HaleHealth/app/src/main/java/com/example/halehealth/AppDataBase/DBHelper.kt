package com.example.halehealth.AppDataBase

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DBHelper (context: Context) : SQLiteOpenHelper(context, BD_NAME, null, VERSAO) {


    companion object {
        private const val BD_NAME = "HaleHealth.db"
        private const val VERSAO = 1
        private const val TABELA = "Usuarios"
        private const val ID = "id"
        private const val NOME = "nome"
        private const val EMAIL = "email"
        private const val SENHA = "senha"
        private const val DNC = "dnc"
        private const val GENERO = "genero"
        private const val ALTURA = "altura"
        private const val PESO = "peso"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = ("CREATE TABLE IF NOT EXISTS $TABELA ("
                + "$ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$NOME TEXT, "
                + "$EMAIL TEXT, "
                + "$SENHA TEXT, "
                + "$DNC INT, "
                + "$GENERO TEXT, "
                + "$ALTURA INT, "
                + "$PESO REAL)")
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABELA")
        onCreate(db)
    }



    fun inserirDados(dnc: String, genero: String, altura: String, peso: String, nome: String?, email: String?, senha: String?) : Boolean{
        val db = this.writableDatabase
        val dados = ContentValues()
        dados.put(NOME, nome)
        dados.put(EMAIL, email)
        dados.put(SENHA, senha)
        dados.put(DNC, dnc)
        dados.put(GENERO, genero)
        dados.put(ALTURA, altura)
        dados.put(PESO, peso)
        val result = db.insert(TABELA, null, dados)
        if (result == -1 .toLong()){
            return false
        }
        return true
    }


        fun checkSenha(email: String, senha: String): Boolean{
            val db = this.writableDatabase
            val query = "SELECT * FROM Usuarios WHERE email = '$email' AND senha = '$senha'"
            val cursor = db.rawQuery(query, null)
            if (cursor.count<=0){
                cursor.close()
                return false
            }
            cursor.close()
            return true
        }




}






