package com.example.halehealth.view

import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.drawerlayout.widget.DrawerLayout
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.halehealth.R

class ActivityHome : AppCompatActivity() {

    lateinit var drawerLayout : DrawerLayout
    private lateinit var receber: BroadcastReceiver

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btAtivarFrequencia = findViewById<AppCompatButton>(R.id.btn_cardiaco)
        val btAtivarOxigenacao = findViewById<AppCompatButton>(R.id.btn_oxigenio)

        drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav,R.string.close_nav)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        btAtivarFrequencia.setOnClickListener{
            val message : String? = "Aaa"
            popupMedirBPM(message)
        }

        btAtivarOxigenacao.setOnClickListener{
            val message : String? = "Aaa"
            popupMedirSP0(message)
        }


    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receber)
    }

    fun homeDisp(view: View) {
        val intent = Intent(this, ActivityDispositivo::class.java)
        startActivity(intent)
    }

    fun homeCores(view: View) {
        val intent = Intent(this, ActivityCores::class.java)
        startActivity(intent)
    }

    fun homeConfig(view: View) {
        val intent = Intent(this, ActivityConfiguracoes::class.java)
        startActivity(intent)
    }

    private fun popupMedirBPM(message : String?){
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_frequencia)
        dialog.window?.setBackgroundDrawable((ColorDrawable(Color.TRANSPARENT)))


        val btMedirBPM : Button = dialog.findViewById(R.id.btnMedir_bpm)
        val btFecharFrequencia : ImageView = dialog.findViewById(R.id.img_fecharFrequencia)
        val txtBPM : TextView = dialog.findViewById(R.id.txtBpm)


        receber = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val data = intent?.getStringExtra("data")
                Log.d("Home", "Dados recebidos: $data")
                txtBPM.text = data
            }
        }

        LocalBroadcastManager.getInstance(this).registerReceiver(receber, IntentFilter("DATA_RECEIVED"))



        btMedirBPM.setOnClickListener{
            Toast.makeText(this, "Clicou em medir", Toast.LENGTH_LONG).show()
        }

        btFecharFrequencia.setOnClickListener{
            dialog.dismiss()
        }


        dialog.show()

    }

    private fun popupMedirSP0(message : String?){
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_oxigenacao)
        dialog.window?.setBackgroundDrawable((ColorDrawable(Color.TRANSPARENT)))

        val btMedirSP0 : Button = dialog.findViewById(R.id.btnMedir_ox)
        val btFecharOxigenacao : ImageView = dialog.findViewById(R.id.img_fecharSp0)
        val txtSp0 : TextView = dialog.findViewById(R.id.txtSp0)

        btMedirSP0.setOnClickListener{
            Toast.makeText(this, "Clicou em medir", Toast.LENGTH_LONG).show()
        }

        btFecharOxigenacao.setOnClickListener{
            dialog.dismiss()
        }


        dialog.show()
    }




}
