package com.example.halehealth.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.text.TextUtils
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.AppDataBase.DBHelper
import com.example.halehealth.R


class ActivityCadastro : AppCompatActivity() {

    private lateinit var userName: EditText
    private lateinit var userEmail: EditText
    private lateinit var userSenha: EditText
    private lateinit var repSenha: EditText
    private lateinit var btnCadastrar: Button
    private lateinit var bd: DBHelper

    private lateinit var ocultarSenha: ImageView
    private lateinit var ocultarRepSenha: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)
        enableEdgeToEdge()

        supportActionBar?.hide()

        ocultarSenha = findViewById(R.id.img_SenhaHide)
        ocultarRepSenha = findViewById(R.id.img_RepSenhaHide)

        userName = findViewById(R.id.edit_cadastroNome)
        userEmail = findViewById(R.id.edit_cadastroEmail)
        userSenha = findViewById(R.id.edit_cadastroSenha)
        repSenha = findViewById(R.id.edit_repetirSenha)
        btnCadastrar = findViewById(R.id.cadastroProximo)
        bd = DBHelper(this)

       btnCadastrar.setOnClickListener{
           val nometext = userName.text.toString()
           val emailtext = userEmail.text.toString()
           val senhatext = userSenha.text.toString()
           val reptSenhatext = repSenha.text.toString()
           val saveData = true

           if (TextUtils.isEmpty(nometext) || TextUtils.isEmpty(emailtext) || TextUtils.isEmpty(senhatext) || TextUtils.isEmpty(reptSenhatext)){
               Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
               } else {
                   if (senhatext.equals(reptSenhatext)){
                       if (saveData == true){
                           Toast.makeText(this, "Cadastro 1/2", Toast.LENGTH_SHORT).show()
                           val intent = Intent(applicationContext, ActivityCadastro2::class.java)
                           intent.putExtra("nome", nometext)
                           intent.putExtra("email", emailtext)
                           intent.putExtra("senha", senhatext)
                           startActivity(intent)
                       } else {
                           Toast.makeText(this, "Usuário existente!", Toast.LENGTH_SHORT).show()
                       }
                   }
               else {
                   Toast.makeText(this, "As senhas não coincidem!", Toast.LENGTH_SHORT).show()
                   }
           }




       }
    }



    fun toLogin(view: View) {
        val intent = Intent(this, ActivityLogin::class.java)
        startActivity(intent)
    }



}
