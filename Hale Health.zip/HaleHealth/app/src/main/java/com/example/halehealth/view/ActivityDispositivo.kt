package com.example.halehealth.view

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Build.VERSION
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.halehealth.R
import java.io.IOException
import java.io.OutputStream
import java.util.UUID


@Suppress("DEPRECATION")
class ActivityDispositivo : AppCompatActivity() {

    private var btPermissao = false

    lateinit var bAdapter : BluetoothAdapter
    private lateinit var bDevice: BluetoothDevice
    private lateinit var bSocket: BluetoothSocket
    private lateinit var outputStream: OutputStream


    private val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val deviceName = "HC-05"



    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dispositivo)

        bAdapter = BluetoothAdapter.getDefaultAdapter()


        val txtOnOff= findViewById<TextView>(R.id.txtOnOff)
        val switchDisp = findViewById<SwitchCompat>(R.id.switchDispositivo)
        val btnEmparelhar = findViewById<Button>(R.id.btn_emparelhar)


        checkPermissions()


        if (bAdapter.isEnabled){
            switchDisp.setChecked(true)
            txtOnOff.text = "Ligado"
        }

        switchDisp.setOnClickListener{

            if(!bAdapter.isEnabled){

                val message : String = "Popup Dispositivo"
                popupDisp(message)
                txtOnOff.text = "Ligado"


            } else {

                txtOnOff.text = "Não ativado"
                switchDisp.setChecked(false)
                bAdapter.disable()

            }


    }

        btnEmparelhar.setOnClickListener{

            val pairedDevices = bAdapter.bondedDevices
            if (pairedDevices.isNotEmpty()) {
                for (device in pairedDevices) {
                    Log.d("HC", "Dispositivo: ${device.name}, ${device.address}")
                    if (device.name == deviceName) {
                        bDevice = device
                        try {
                            bSocket = bDevice.createRfcommSocketToServiceRecord(uuid)
                            bAdapter.cancelDiscovery()
                            bSocket.connect()
                            outputStream = bSocket.outputStream
                            Toast.makeText(this, "Conectado ao Hale Bracelete", Toast.LENGTH_LONG).show()

                            ConnectedThread(bSocket).start()

                        } catch (e: IOException) {
                            Log.e("HC", "Falha na conexão: ${e.message}")
                            Toast.makeText(this, "Falha na conexão: ${e.message}", Toast.LENGTH_SHORT).show()

                            Toast.makeText(this, "Emparelhe o Bluetooth com o HC-05 (sistema do seu celular): ${e.message}", Toast.LENGTH_SHORT).show()

                            try {
                                bSocket.close()
                            } catch (closeException: IOException) {
                                Log.e("HC", "Erro ao fechar o socket: ${closeException.message}")
                            }
                        }
                        break
                    }
                }
            } else {
                Toast.makeText(this, "Nenhum dispositivo emparelhado encontrado", Toast.LENGTH_SHORT).show()
            }

        }



}




    private fun popupDisp (message : String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_bluetooth)
        dialog.window?.setBackgroundDrawable((ColorDrawable(Color.TRANSPARENT)))

        val btAtivar : Button = dialog.findViewById(R.id.popupAtivar)
        val btFechar : Button = dialog.findViewById(R.id.popupFechar)


        btFechar.setOnClickListener{
            dialog.dismiss()
            val txtOnOff= findViewById<TextView>(R.id.txtOnOff)
            val switchDisp = findViewById<SwitchCompat>(R.id.switchDispositivo)
            txtOnOff.text = "Não ativado"
            switchDisp.setChecked(false)
        }

        btAtivar.setOnClickListener{
            val btManager : BluetoothManager = getSystemService(BluetoothManager :: class.java)
            val btAdapter : BluetoothAdapter = btManager.adapter
            if (btAdapter == null) {
                Toast.makeText(this, "O dispositivo não suporta Bluetooth", Toast.LENGTH_LONG).show()
            } else {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_ADMIN)
                }

            }
            dialog.dismiss()
        }

        dialog.show()
    }

    private val btPermissionLauncher = registerForActivityResult(RequestPermission()){
            maior:Boolean ->
        if(maior){
            val btManager : BluetoothManager = getSystemService(BluetoothManager :: class.java)
            val btAdapter : BluetoothAdapter? = btManager.adapter

            btPermissao = true
            if (btAdapter?.isEnabled == false) {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                btResultLauncher.launch(intent)
            } else {
                BluetoothAtivado()
            }
        } else {

        }
    }


    private val btResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            resultado : ActivityResult ->
        if (resultado.resultCode == RESULT_OK) {

            BluetoothAtivar()

        } else {

            val txtOnOff= findViewById<TextView>(R.id.txtOnOff)
            val switchDisp = findViewById<SwitchCompat>(R.id.switchDispositivo)

            switchDisp.setChecked(false)
            txtOnOff.text = "Não ativado"
            Toast.makeText(this, "Clique em permitir!", Toast.LENGTH_LONG).show()
        }
    }



    private fun BluetoothAtivar(){
        Toast.makeText(this, "O Bluetooth foi ativado!", Toast.LENGTH_LONG).show()
    }

    private fun BluetoothAtivado(){
        Toast.makeText(this, "O Bluetooth já está ativado!", Toast.LENGTH_LONG).show()
    }


    fun dispHome(view: View) {
        val intent = Intent(this, ActivityHome::class.java)
        startActivity(intent)
    }

    fun dispCores(view: View) {
        val intent = Intent(this, ActivityCores::class.java)
        startActivity(intent)
    }

    fun dispConfig(view: View) {
        val intent = Intent(this, ActivityConfiguracoes::class.java)
        startActivity(intent)
    }


    override fun onDestroy() {
        super.onDestroy()
        try {
            bSocket.close()
        } catch (e: IOException) {
            Log.e("HC", "Erro ao fechar o socket: ${e.message}")
        }
    }


    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION),
                1)
        }
    }

    inner class ConnectedThread(private val socket: BluetoothSocket) : Thread() {
        override fun run() {
            val buffer = ByteArray(1024) // buffer para armazenar dados recebidos
            var bytes: Int

            val inputStream = socket.inputStream

            while (true) {
                try {
                    bytes = inputStream.read(buffer)
                    val receivedData = String(buffer, 0, bytes)
                    Log.d("HC", "Dados recebidos: $receivedData")
                    LocalBroadcastManager.getInstance(this@ActivityDispositivo).sendBroadcast(intent)
                    // Aqui você pode enviar os dados para a ActivityHome usando LocalBroadcastManager
                } catch (e: IOException) {
                    Log.e("HC", "Erro na leitura: ${e.message}")
                    break
                }
            }
        }
    }
}