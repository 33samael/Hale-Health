package com.example.halehealth.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.R

class ActivityCores : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cores)

        }

    fun coresDisp(view: View) {
        val intent = Intent(this, ActivityDispositivo::class.java)
        startActivity(intent)
    }

    fun coresHome(view: View) {
        val intent = Intent(this, ActivityHome::class.java)
        startActivity(intent)
    }

    fun coresConfig(view: View) {
        val intent = Intent(this, ActivityConfiguracoes::class.java)
        startActivity(intent)
    }
}