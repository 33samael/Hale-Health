package com.example.halehealth.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.R

class ActivityConfiguracoes : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuracoes)
    }

    fun configDisp(view: View) {
        val intent = Intent(this, ActivityDispositivo::class.java)
        startActivity(intent)
    }

    fun configHome(view: View) {
        val intent = Intent(this, ActivityHome::class.java)
        startActivity(intent)
    }

    fun configCores(view: View) {
        val intent = Intent(this, ActivityCores::class.java)
        startActivity(intent)
    }
}